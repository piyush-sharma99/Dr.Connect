package x17521139.student.ncirl.ie.drconnectapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class HomePage extends AppCompatActivity {
    private ImageButton pres,doctor,appt,notif,nfc;
    private Button logOutBtn;
    private final String TAG = "HomePage";
    private static String FNAME = "fName";
    private TextView textViewData;

    private DocumentReference noteRef;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        textViewData = findViewById(R.id.textViewData);

        pres = (ImageButton)findViewById(R.id.presBtn);
        pres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPres();
            }
        });

        doctor = (ImageButton)findViewById(R.id.doctorBtn);
        doctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDoctor();
            }
        });

        appt = (ImageButton)findViewById(R.id.apptBtn);
        appt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAppt();
            }
        });

        notif = (ImageButton)findViewById(R.id.notifBtn);
        notif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNotif();
            }
        });

        nfc = (ImageButton)findViewById(R.id.nfcBtn);
        nfc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNfc();
            }
        });

        logOutBtn = (Button)findViewById(R.id.logOutBtn);
        logOutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLogIn();
            }
        });

        //loadNote(View);
    }

    public void openPres(){
        Intent intentPres = new Intent(this, Prescriptions.class);
        startActivity(intentPres);
    }
    public void openDoctor(){
        Intent intentDoctor = new Intent(this, Doctor.class);
        startActivity(intentDoctor);
    }
    public void openAppt(){
        Intent intentAppt = new Intent(this, Appointments.class);
        startActivity(intentAppt);
    }
    public void openNotif(){
        Intent intentNotif = new Intent(this, Notifications.class);
        startActivity(intentNotif);
    }

    public void openNfc(){
        Intent intentNfc = new Intent(this, NfcConnect.class);
        startActivity(intentNfc);
    }

    public void openLogIn(){
        Intent intentLogIn = new Intent(this, MainActivity.class);
        startActivity(intentLogIn);
    }
    public void loadNote(View v) {
        noteRef.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            String fname = documentSnapshot.getString(FNAME);

                            //String description = documentSnapshot.getString(DOCNUM);

                            //Map<String, Object> note = documentSnapshot.getData();

                            textViewData.setText( "\n"+"Welcome "+fname );
                        } else {
                            Toast.makeText(HomePage.this, "Document does not exist", Toast.LENGTH_SHORT).show();
                        }


                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(HomePage.this, "Error!", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
    }
}
