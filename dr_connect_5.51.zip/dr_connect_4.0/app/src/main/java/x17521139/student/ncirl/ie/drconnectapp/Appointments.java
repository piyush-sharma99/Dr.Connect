package x17521139.student.ncirl.ie.drconnectapp;

// @author: Keith Mahony - UI, firebase integration, send and store new collection in database
// @author: Ben Carroll -
// @author: Piyush Sharma -
// @author: Dylan Murphy -

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Appointments extends AppCompatActivity {

    private EditText dateTf, timeTf, locTf;
    private Button submitBtn;
    private FirebaseAuth mAuth;
    private ProgressBar progressBar;
    private static final String TAG = "Appointments";

    //private DocumentReference noteRef;
    FirebaseFirestore db = FirebaseFirestore.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointments);

        FirebaseApp.initializeApp(this);
        initializeUI();
        mAuth = FirebaseAuth.getInstance();

        submitBtn = (Button) findViewById(R.id.submitBtn);
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addAppointment();
            }
        });



    }

    private void addAppointment(){

        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        String date = dateTf.getText().toString();
        String time = timeTf.getText().toString();
        String loc = locTf.getText().toString();

        Map<String, Object> info = new HashMap<>();
        info.put("date", date);
        info.put("time", time);
        info.put("location", loc);

        db.collection("Doctor").document(uid).collection("Appointments")
                .add(info)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d(TAG, "Document Snapshot successfully written!" +documentReference.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });
    }

    private void initializeUI() {
        locTf = findViewById(R.id.locTf);
        dateTf = findViewById(R.id.dateTf);
        timeTf = findViewById(R.id.timeTf);
    }

}

