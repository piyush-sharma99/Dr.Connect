package x17521139.student.ncirl.ie.drconnectapp;

// @author Keith Mahony - Read user specific prescription data from firebase and display
// @author Ben Carroll - validation, links from home page, UI, design, visuals
// @author Matthew Byrne - visuals/imagery

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class Prescriptions extends AppCompatActivity {

    FirebaseFirestore db = FirebaseFirestore.getInstance();


    private DocumentReference noteRef;

    private static final String TAG = "Prescriptions";

    private static final String DESC = "description";
    private static final String DOCID = "DocID";
    private static final String DOCNUM = "docnum";
    private static final String MED1 = "med1";
    private static final String MED2 = "med2";
    private static final String MED3 = "med3";

    private String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

   // private EditText editTextTitle;
    //private EditText editTextDescription;
    private TextView textViewData;
    private Button getDataBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescriptions);
        initialiseUI();
        getUID();

        getDataBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                noteRef = db.document("Prescription/"+uid);
                getPres(v);
            }
        });


    }


    public void getPres(View v) {
        noteRef.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            String desc = documentSnapshot.getString(DESC);
                            String docID = documentSnapshot.getString(DOCID);
                            String med1 = documentSnapshot.getString(MED1);
                            String med2 = documentSnapshot.getString(MED2);
                            String med3 = documentSnapshot.getString(MED3);

                            String description = documentSnapshot.getString(DOCNUM);

                            //Map<String, Object> note = documentSnapshot.getData();

                            textViewData.setText( "\n"+"Doctor: " + docID + "\n"+ "\n" + "\n"+ "Description: " + desc+ "\n" + "\n" + "\n"+ "Medication 1: "+med1+ "\n" + "\n" + "\n"+"Medication 2: "+med2+ "\n" + "\n" + "\n"+"Medication 3: "+med3 );
                        } else {
                            Toast.makeText(Prescriptions.this, "Document does not exist", Toast.LENGTH_SHORT).show();
                        }


                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Prescriptions.this, "Error!", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
    }
    public void initialiseUI(){
       // editTextTitle = findViewById(R.id.editTextTitle);
        //editTextDescription = findViewById(R.id.editTextDescription);
        textViewData = findViewById(R.id.textViewData);
        getDataBtn = findViewById(R.id.getDataBtn);
    }

    public void getUID() {
        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Toast.makeText(this, "" + currentFirebaseUser.getUid(), Toast.LENGTH_SHORT).show();
    }
}

