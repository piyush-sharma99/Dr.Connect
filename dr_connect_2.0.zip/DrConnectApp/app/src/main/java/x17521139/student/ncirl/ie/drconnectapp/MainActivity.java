package x17521139.student.ncirl.ie.drconnectapp;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    EditText emailTf, passwordTf;
    TextView messageLbl;
    ProgressDialog progressDialog;
    FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button createBtn = (Button) findViewById(R.id.createBtn);
        Button loginBtn = (Button) findViewById(R.id.loginBtn);

        auth = FirebaseAuth.getInstance();
        emailTf = (EditText) findViewById(R.id.cEmailTf);
        passwordTf = (EditText) findViewById(R.id.passwordTf);
        messageLbl = (TextView) findViewById(R.id.messageLbl);
        progressDialog = new ProgressDialog(this);


        loginBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {


                String email = emailTf.getText().toString();
                String password = passwordTf.getText().toString();

                if (email.equals("") && password.equals("")) {
                    Toast.makeText(getApplicationContext(), "email/password is blank", Toast.LENGTH_LONG).show();
                } else {
                    progressDialog.setMessage("Registering please wait....");
                    progressDialog.show();
                    auth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        progressDialog.hide();
                                        Toast.makeText(getApplicationContext(), "User registered", Toast.LENGTH_LONG).show();


                                    }
                                    else{
                                        progressDialog.hide();
                                        Toast.makeText(getApplicationContext(), "User not registered", Toast.LENGTH_LONG).show();
                                    }

                                }
                            });

                }
            }
        });

        /*loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {





                /*if( email.equals("x17521139@student.ncirl.ie") && password.equals("Keith")){
                    messageLbl.setText("You have logged in");

                }
                else{
                    messageLbl.setText("No account found");
                }

            }
        });*/

        /*createBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(getApplicationContext(), CreateAccount.class));
            }
        });*/

    }
}
